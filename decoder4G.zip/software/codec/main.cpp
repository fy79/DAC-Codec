#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <memory.h>
#include <math.h>
#include <float.h>
#include <bit>
#include <iostream>
using namespace std;
typedef unsigned char byte;
////////////////////////////////////////////////////////////////////////////////////////////////
const int DECGEN = 4;
const int n=(1<<8), t=40, M=(1<<6), nccs=(1<<7), nseg=(1<<10);
const double p=.12, HX = -p*log2(p)-(1-p)*log2(1-p), R=1/3.0, r=(n*R/HX-t)/(n-t), q[2]={.1,.1};
////////////////////////////////////////////////////////////////////////////////////////////////
double steps[3];
void set_steps(double p, double r){
    cout<<"r = "<<r<<endl;
    steps[0] = 1-p;
    steps[1] = pow(1-p,r); // (1-p)^r => [0, steps[1])
    steps[2] = 1-pow(p,r); // 1-p^r => [steps[2], 1)
}// [0, steps[2], steps[0], steps[1], 1)
////////////////////////////////////////////////////////////////////////////////////////////////
double lgp[2], lgq[2][2];
void set_metrics(const double p, const double q[]){
    lgp[0] = log(1-p);
    lgp[1] = log(p);
    lgq[0][0] = log(1-q[0]);
    lgq[0][1] = log(q[0]);
    lgq[1][0] = log(q[1]);
    lgq[1][1] = log(1-q[1]);
}
////////////////////////////////////////////////////////////////////////////////////////////////
const int WIDTH = 32;
const unsigned HRNG = (1U<<(WIDTH-1));    // half of the range
const unsigned QRNG = (1U<<(WIDTH-2));    // quarter of the range
const unsigned MASK = HRNG|(HRNG-1);
////////////////////////////////////////////////////////////////////////////////////////////////
void encode_symbol(byte *str, unsigned &low, unsigned &high, int &j, int &u, byte x, char b=1){
    double length = (high-low+1.0);
    if(b<0){
        if(x){
            unsigned sen1 = 1 << (31 - __builtin_clz(length*p));
            low = high - (sen1-1U);
        }else{
            unsigned sen0 = 1 << (31 - __builtin_clz(length*(1-p)));
            high = low + (sen0-1U);
        }
    }else{
        int a = b+(b&x);
        if(x) low += unsigned(length*steps[a]+0.5);
        else  high = low + unsigned(length*steps[a]-0.5);
    }
    while(!((high^low)&HRNG)){
        str[j++] = (low>=HRNG);
        while(u){
            str[j++] = (low<HRNG);
            u--;
        }
        low <<= 1; high <<= 1; high |= 1;
    }
    while((high&QRNG)<(low&QRNG)){
        u++;
        low  -= QRNG; low  <<= 1;
        high -= QRNG; high <<= 1; high |= 1;
    }
}
int compress(byte *str, const byte *x, int n, int t){
    int j=0, u=0;
    unsigned low=0, high=MASK;
    for(int i=0; i<n; i++){
        encode_symbol(str, low, high, j, u, x[i], (i<(n-t))-(i>(n-2)));
    }
    return j;
}
////////////////////////////////////////////////////////////////////////////////////////////////
struct NODE{
    NODE *parent, *kid[2];
};
static NODE node[(M<<1)*n];
struct ENDN{
    unsigned low, high, code, j, u;
    double incmet, metric;
    NODE *node;
};
static ENDN endn[(M<<1)];
////////////////////////////////////////////////////////////////////////////////////////////////
void create_root(const byte *str){
    endn->node = node;
    endn->node->parent = NULL; endn->node->kid[0] = NULL; endn->node->kid[1] = NULL;
    endn->low = 0; endn->high = MASK; endn->code = 0; endn->j = 0; endn->u = 0;
    for(int i=0; i<WIDTH; i++){
        endn->code <<= 1;
        endn->code |= str[(endn->j)++];
    }
    endn->incmet = 0.0;
}
////////////////////////////////////////////////////////////////////////////////////////////////
byte get_symbol(unsigned low, unsigned high, unsigned code, bool b=true){
    double length = (high-low+1.0);
    if((code-low)<unsigned(length*steps[b<<1]+0.5))     return 0;   // < 1-p^r or (1-p)
    else if((code-low)>unsigned(length*steps[b]-0.5))   return 1;   // >= (1-p)^r or (1-p)
    else                                                return 2;
}
void remove_symbol(const byte *str, unsigned &low, unsigned &high, unsigned &code, unsigned &j, unsigned &u, byte x, bool b=true){
    int a = b+(b&x);
    double length = (high-low+1.0);
    if(x) low += unsigned(length*steps[a]+0.5);
    else  high = low + unsigned(length*steps[a]-0.5);
    while(!((high^low)&HRNG)){
        u = 0;
        low  <<= 1;
        high <<= 1; high |= 1;
        code <<= 1; code |= str[j++];
    }
    while((high&QRNG)<(low&QRNG)){
        u++;
        low  -= QRNG; low  <<= 1;
        high -= QRNG; high <<= 1; high |= 1;
        code -= QRNG; code <<= 1; code |= str[j++];
    }
}
void create_kid(const byte *str, ENDN *endn, int &nNodes, byte x, byte y, double r=1){
    NODE *parent = endn->node, *kid = node+(nNodes++);
    parent->kid[x] = kid; kid->parent = parent; kid->kid[0] = NULL; kid->kid[1] = NULL;
    endn->node = kid;
    remove_symbol(str, endn->low, endn->high, endn->code, endn->j, endn->u, x, r<1);
    if(DECGEN>1){
        endn->incmet += lgq[x][y] + (1-r)*lgp[x];   // update incremental metric
    }else{
        endn->incmet += lgq[x][y] + lgp[x];         // update incremental metric
    }
    endn->metric = endn->incmet;
}
void extend(const byte *str, int &nEnds, int &nNodes, byte y, double r=1){
    int nKids = nEnds;
    for(int k=0; k<nEnds; k++){// for each active path
        byte x = get_symbol((endn+k)->low, (endn+k)->high, (endn+k)->code, r<1);
        if(x==2){// fork node
            memcpy(endn+nKids, endn+k, sizeof(ENDN));
            create_kid(str, endn+(nKids++), nNodes, !y, y, r);
            create_kid(str, (endn+k), nNodes, y, y, r);
        }else{// 0/1 node
            create_kid(str, (endn+k), nNodes, x, y, r);
        }
    }
    nEnds = nKids;
}
////////////////////////////////////////////////////////////////////////////////////////////////
byte get_symbol_leaf(double &meta, unsigned low, unsigned high, unsigned code){
    double length = (high-low+1.0);
    unsigned sen1 = 1 << (31 - __builtin_clz(length*p));        //(1U<<int(log2(length*p)));
    unsigned sen0 = 1 << (31 - __builtin_clz(length*(1-p)));    //(1U<<int(log2(length*(1-p))));
    if(code<(low+sen0)){
        meta = lgp[0] - log(sen0/length);
        return 0;
    }else if(code>(high-sen1)){
        meta = lgp[1] - log(sen1/length);
        return 1;
    }else{
        return 2;
    }
}
void remove_symbol_leaf(const byte *str, unsigned &low, unsigned &high, unsigned &j, unsigned &u, byte x){
    double length = (high-low+1.0);
    if(x){
        unsigned sen1 = 1 << (31 - __builtin_clz(length*p));
        low = high - (sen1-1U);
    }else{
        unsigned sen0 = 1 << (31 - __builtin_clz(length*(1-p)));
        high = low + (sen0-1U);
    }
    while(!((high^low)&HRNG)){
        u = 0;
        low <<= 1; high <<= 1; high |= 1;
        j++;
    }
    while((high&QRNG)<(low&QRNG)){
        u++;
        low  -= QRNG; low  <<= 1;
        high -= QRNG; high <<= 1; high |= 1;
        j++;
    }
}
void extend_leaf(const byte *str, int nEnds, int &nNodes, byte y, int m){
    for(int k=0; k<nEnds; k++){// for each active path
        double meta;
        byte x = get_symbol_leaf(meta, (endn+k)->low, (endn+k)->high, (endn+k)->code);
        if(x==2){// in error
            (endn+k)->metric = -FLT_MAX;
        }else{// 0/1 node
            remove_symbol_leaf(str, (endn+k)->low, (endn+k)->high, (endn+k)->j, (endn+k)->u, x);
            if(DECGEN<3){
                NODE *parent = (endn+k)->node, *kid = node+(nNodes++);
                parent->kid[x] = kid; kid->parent = parent; kid->kid[0] = NULL; kid->kid[1] = NULL; 
                (endn+k)->node = kid;
                if(DECGEN==1){
                    (endn+k)->metric = (endn+k)->incmet + lgq[x][y] + lgp[x];
                }else{
                    (endn+k)->metric = (endn+k)->incmet + lgq[x][y] + meta;
                }
            }else{
                if((endn[k].j) != m + (endn[k].u) + WIDTH){
                    (endn+k)->metric = -FLT_MAX;
                }else{
                    NODE *parent = (endn+k)->node, *kid = node+(nNodes++);
                    parent->kid[x] = kid; kid->parent = parent; kid->kid[0] = NULL; kid->kid[1] = NULL; 
                    (endn+k)->node = kid;
                    if(DECGEN==3){
                        (endn+k)->metric = (endn+k)->incmet + lgq[x][y] + meta;
                    }else{
                        (endn+k)->metric = (endn+k)->incmet + lgq[x][y] + meta - ((endn[k].u)+(endn[k].low>0))*log(2);
                    }
                }
            }
        }
    }
}
////////////////////////////////////////////////////////////////////////////////////////////////
int compare(const void *a, const void *b){
    double ma = ((ENDN*)a)->metric, mb = ((ENDN*)b)->metric;
    return (ma<mb)-(ma>mb);
}
void traceback(byte *xr, NODE *leaf, int n){
    NODE *now = leaf;
    for(int i=(n-1); i>=0; i--){
        xr[i] = (now==(now->parent->kid[1]));
        now = (now->parent);
    }
}
void add_int_met(int nEnds, double *ccs, int nseg){
    for(int k=0; k<nEnds; k++){
        double u = (((endn+k)->code)-((endn+k)->low))/(((endn+k)->high)-((endn+k)->low)+1.0);
        (endn+k)->metric += ccs[int(u*nseg)];
    }
}
int expand(byte *xr, const byte *str, const byte *y, double **ccs, int nccs, int nseg, int M, int n, double r, int t, int m){
    create_root(str);
    int nNodes=1, nEnds=1;
    for(int i=0; i<(n-t); i++){
        extend(str, nEnds, nNodes, y[i], r);
        if(DECGEN>1){
            add_int_met(nEnds, ccs[max(0,min((n-t-i),nccs)-1)], nseg);
        }
        if(nEnds>M && i<(n-t-1)){
            qsort(endn, nEnds, sizeof(ENDN), compare); // sort paths in the descending order of metric
            nEnds = M;
        }
    }
    for(int i=(n-t); i<(n-1); i++){
        extend(str, nEnds, nNodes, y[i]);
    }
    extend_leaf(str, nEnds, nNodes, y[n-1], m);
    qsort(endn, nEnds, sizeof(ENDN), compare); // sort paths in the descending order of metric
    if(endn[0].metric>-FLT_MAX){
        traceback(xr, endn[0].node, n);
    }
    return nNodes;
}
////////////////////////////////////////////////////////////////////////////////////////////////
int count_errors(const byte *rec, const byte *src, int n){
    int nerrs = 0;
    for (int i = 0; i < n; i++){
        nerrs += (rec[i]^src[i]);
    }
    return nerrs;
}
////////////////////////////////////////////////////////////////////////////////////////////////
void getccs(double **ccs, double p, double r, int n, int m){
    for(int j=0; j<m; j++){
        ccs[0][j] = 1;
    }
    for(int i=1; i<n; i++){
        memset(ccs[i], 0, m*sizeof(double));
        double scale0 = pow(1-p,-r);    // (1-p)^(-r)
        for(int j=0; j<int(ceil(m/scale0)); j++){
            /* j<ceil(m(1-p)^r) guarantees alpha<m */
            double alpha=j*scale0, beta=alpha+scale0;
            double temp = (alpha>0) ? (ceil(alpha)-alpha)*ccs[i-1][int(ceil(alpha))-1] : 0;
            if(beta>=m){
                for(int k=int(ceil(alpha)); k<m; k++){
                    temp += ccs[i-1][k];
                }
            }else{
                for(int k=int(ceil(alpha)); k<int(beta); k++){
                    temp += ccs[i-1][k];
                }
                temp += (beta-int(beta))*ccs[i-1][int(beta)];
            }
            ccs[i][j] = (1-p)*temp;
        }
        double scale1 = pow(p,-r), shift = m*(1-pow(p,r));
        for(int j=int(shift); j<m; j++){
            /* j>=floor(m(1-p^r)) guarantees beta>0 */
            double alpha=(j-shift)*scale1, beta=alpha+scale1;
            double temp = (beta<m) ? (beta-int(beta))*ccs[i-1][int(beta)] : 0;
            if(alpha<=0){
                for(int k=0; k<int(beta); k++){
                    temp += ccs[i-1][k];
                }
            }else{
                temp += (ceil(alpha)-alpha)*ccs[i-1][int(ceil(alpha))-1];
                for(int k=int(ceil(alpha)); k<int(beta); k++){
                    temp += ccs[i-1][k];
                }
            }
            ccs[i][j] += p*temp;
        }
    }
}
////////////////////////////////////////////////////////////////////////////////////////////////
int main(int argc, char *argv[]){
    set_steps(p,r);
    set_metrics(p,q);
        
    /* initialize CCS array */
    double **ccs = new double*[nccs];
    for(int i=0; i<nccs; i++){// for each stage
        ccs[i] = new double[nseg];
    }
    getccs(ccs, p, r, nccs, nseg);
    for(int i=0; i<nccs; i++){
        for(int j=0; j<nseg; j++){
            ccs[i][j] = log(ccs[i][j]);
        }
    }
    cout<<"CCS initialization over!"<<endl;

    srand(0);
    // loop for trials
    int nefs = 0, nebs = 0, ntries = 0;
    byte *x=new byte[8*n], *y=x+n, *xr=y+n, *str=xr+n;
    while(1){
        for(int i=0; i<n; i++){
            x[i] = (rand()<RAND_MAX*p);
            y[i] = x[i]^(rand()<RAND_MAX*q[x[i]]);
            if(y[i]){
                xr[i] = ((1-p)*q[0]<p*(1-q[1]));
            }else{
                xr[i] = ((1-p)*(1-q[0])<p*q[1]);
            }
        }
        memset(str, 0, 5*n*sizeof(byte));
        int m = compress(str,x,n,t);
        str[m] = 1;

        expand(xr,str,y,ccs,nccs,nseg,M,n,r,t,m);
        int temp = count_errors(x, xr, n);
        nefs += (temp>0);
        nebs += temp;
        ntries++;
        if((ntries>=(1<<20)) || (nefs>=(1<<10))){
            break;
        }
    }
    printf("FER = %f\nBER = %f\n", nefs/float(ntries), nebs/float(n*ntries));
    delete[] x;
    for (int i=0; i<nccs; i++) {
        delete[] ccs[i];
    }
    delete[] ccs;
    return 0;
}
