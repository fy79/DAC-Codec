%% M
g1fer = [0.772247, 0.655990, 0.555918, 0.508694, 0.486692];
g1ser = [0.075332, 0.060853, 0.050620, 0.045796, 0.043448];

g2fer = [0.512513, 0.278867, 0.160905, 0.099215, 0.069447];
g2ser = [0.048154, 0.025211, 0.014262, 0.008547, 0.005735];

g3fer = [0.511488, 0.275343, 0.155034, 0.090579, 0.060402];
g3ser = [0.051698, 0.027515, 0.015310, 0.008839, 0.005697];

g4fer = [0.510469, 0.272413, 0.151122, 0.086824, 0.054912];
g4ser = [0.051566, 0.027317, 0.015012, 0.008574, 0.005328];

M = [2,3,4,5,6];
figure(1);
semilogy(M,g1fer,'-+'); hold on;
semilogy(M,g2fer,'-x');
semilogy(M,g3fer,'-o');
semilogy(M,g4fer,'-*');
ylabel({'FER'}, 'interpreter', 'latex');
xlabel({'$\log_2{M}$'}, 'interpreter', 'latex');
grid on;
axis tight;
set(gca, 'fontsize', 16);
legend({'1G','2G','3G','4G'}, 'interpreter', 'latex','location','best');
title({'$n=2^8$, $t=40$, $\epsilon=\varepsilon=0.1$, $R=1/3$, $N=2^{10}$'}, 'interpreter', 'latex');

figure(2);
semilogy(M,g1ser,'-+'); hold on;
semilogy(M,g2ser,'-x');
semilogy(M,g3ser,'-o');
semilogy(M,g4ser,'-*');
ylabel({'SER'}, 'interpreter', 'latex');
xlabel({'$\log_2{M}$'}, 'interpreter', 'latex');
grid on;
axis tight;
set(gca, 'fontsize', 16);
legend({'1G','2G','3G','4G'}, 'interpreter', 'latex','location','best');
title({'$n=2^8$, $t=40$, $\epsilon=\varepsilon=0.1$, $R=1/3$, $N=2^{10}$'}, 'interpreter', 'latex');


%% crossover
g2fer = [0.069447, 0.088162, 0.113062, 0.144796, 0.173471];
g2ser = [0.005735, 0.007460, 0.009833, 0.013077, 0.016036];

g3fer = [0.060402, 0.079602, 0.101126, 0.129555, 0.158612];
g3ser = [0.005697, 0.007598, 0.009796, 0.012808, 0.016008];

g4fer = [0.054912, 0.072158, 0.092244, 0.118711, 0.146579];
g4ser = [0.005328, 0.007002, 0.009100, 0.011939, 0.014967];

q = [.1, .105, .11, .115, .12];
figure(3);
semilogy(q,g2fer,'-x'); hold on;
semilogy(q,g3fer,'-o');
semilogy(q,g4fer,'-*');
ylabel({'FER'}, 'interpreter', 'latex');
xlabel({'$\varepsilon$'}, 'interpreter', 'latex');
grid on;
axis tight;
set(gca, 'fontsize', 16);
legend({'2G','3G','4G'}, 'interpreter', 'latex','location','best');
title({'$n=2^8$, $t=40$, $\epsilon=0.1$, $R=1/3$, $N=2^{10}$, $M=2^6$'}, 'interpreter', 'latex');

figure(4);
semilogy(q,g2ser,'-x'); hold on;
semilogy(q,g3ser,'-o');
semilogy(q,g4ser,'-*');
ylabel({'SER'}, 'interpreter', 'latex');
xlabel({'$\varepsilon$'}, 'interpreter', 'latex');
grid on;
axis tight;
set(gca, 'fontsize', 16);
legend({'2G','3G','4G'}, 'interpreter', 'latex','location','best');
title({'$n=2^8$, $t=40$, $\epsilon=0.1$, $R=1/3$, $N=2^{10}$, $M=2^6$'}, 'interpreter', 'latex');


%% bias
g2fer = [0.069447, 0.104532, 0.152859, 0.214092, 0.273067];
g2ser = [0.005735, 0.009272, 0.014585, 0.021516, 0.028820];

g3fer = [0.060402, 0.096604, 0.143558, 0.206785, 0.265974];
g3ser = [0.005697, 0.009555, 0.015034, 0.022354, 0.029799];

g4fer = [0.054912, 0.090828, 0.137137, 0.199106, 0.260958];
g4ser = [0.005328, 0.009094, 0.014399, 0.021539, 0.029020];

p = [.1, .105, .11, .115, .12];
figure(5);
semilogy(p,g2fer,'-x'); hold on;
semilogy(p,g3fer,'-o');
semilogy(p,g4fer,'-*');
ylabel({'FER'}, 'interpreter', 'latex');
xlabel({'$\epsilon$'}, 'interpreter', 'latex');
grid on;
axis tight;
set(gca, 'fontsize', 16);
legend({'2G','3G','4G'}, 'interpreter', 'latex','location','best');
title({'$n=2^8$, $t=40$, $\varepsilon=0.1$, $R=1/3$, $N=2^{10}$, $M=2^6$'}, 'interpreter', 'latex');

figure(6);
semilogy(p,g2ser,'-x'); hold on;
semilogy(p,g3ser,'-o');
semilogy(p,g4ser,'-*');
ylabel({'SER'}, 'interpreter', 'latex');
xlabel({'$\epsilon$'}, 'interpreter', 'latex');
grid on;
axis tight;
set(gca, 'fontsize', 16);
legend({'2G','3G','4G'}, 'interpreter', 'latex','location','best');
title({'$n=2^8$, $t=40$, $\varepsilon=0.1$, $R=1/3$, $N=2^{10}$, $M=2^6$'}, 'interpreter', 'latex');

